// Initialize Firebase
export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyDREXCQ7bXSB0RgIps-D9mBCy1HsFSSnCQ',
    authDomain: 'final-project-03.firebaseapp.com',
    databaseURL: 'https://final-project-03.firebaseio.com',
    projectId: 'final-project-03',
    storageBucket: 'final-project-03.appspot.com',
    messagingSenderId: '656175338897'
  }
};
