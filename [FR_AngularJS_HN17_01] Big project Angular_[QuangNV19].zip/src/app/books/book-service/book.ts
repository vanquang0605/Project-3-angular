export class Book {
  title: string;
  description: string;
  authors: string[];
  pageCount: string;
  imageLinks: string;
  $key: string;
  user: string;
}
