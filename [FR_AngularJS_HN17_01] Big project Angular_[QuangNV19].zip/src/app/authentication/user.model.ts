export class User {
  email: string;
}
